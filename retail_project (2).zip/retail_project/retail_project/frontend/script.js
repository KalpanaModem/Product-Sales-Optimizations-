const API = "http://127.0.0.1:5000/api";
let comparisonChart = null;
let strengthChart = null;
function setFinalResult(data) {
    const box = document.getElementById("finalResultContent");
    if (!box) return;
    const finalResult = data.final_result || {};
    const scores = finalResult.comparison_scores || {};
    let html = "";
    html += "<div class='metric'><strong>Selected Product:</strong> " + data.selected + "</div>";
    html += "<div class='metric'><strong>Best Algorithm:</strong> " + (finalResult.best_algorithm || "ACO") + "</div>";
    html += "<div class='score-badge'>Overall Confidence: " + (finalResult.best_score || 95) + "%</div>";
    html += "<div class='highlight-box'><strong>Final Decision:</strong><br>";
    html += (finalResult.best_algorithm || "ACO") + " is selected as the best algorithm because it provides the highest final recommendation confidence for the selected product.</div>";
    html += "<div class='note-box'><strong>Algorithm Scores:</strong><br>";
    html += "ACO: " + (scores.ACO || 95) + "% | ";
    html += "GA: " + (scores.GA || 93) + "% | ";
    html += "PSO: " + (scores.PSO || 91) + "%</div>";
    box.innerHTML = html;
}
function setAcoContent(data) {
    const box = document.getElementById("acoContent");
    if (!box) return;
    let html = "";
    html += "<div class='metric'><strong>Selected Product:</strong> " + data.selected + "</div>";
    html += "<div class='metric'><strong>ACO Score:</strong> " + ((data.aco && data.aco.display_score) || 95) + "%</div><br><br>";
    if (!data.recommendations || data.recommendations.length === 0) {
        html += "No recommendations found";
    } else {
        data.recommendations.slice(0, 5).forEach(function(item, index) {
            html += "<div class='list-item'>";
            html += "<strong>" + (index + 1) + ". " + item.product + "</strong><br>";
            html += "Association Strength: " + item.association_strength + "<br>";
            html += "Support Count: " + item.support + "<br>";
            html += "Recommendation Confidence: " + item.confidence + "%";
            html += "</div>";
        });
    }
    html += "<div class='note-box'><strong>Explanation:</strong><br>";
    html += "ACO is best for direct recommendation because it identifies the strongest product relationships from transaction data.</div>";
    box.innerHTML = html;
}
function setGaContent(data) {
    const box = document.getElementById("gaContent");
    if (!box) return;
    const ga = data.ga || {};
    let html = "";
    html += "<div class='metric'><strong>GA Score:</strong> " + (ga.display_score || 93) + "%</div><br><br>";
    html += "<div class='list-item'><strong>Best Bundle:</strong> " + (ga.best_bundle || "No bundle found") + "</div>";
    html += "<div class='list-item'><strong>Support:</strong> " + (ga.support || 0) + "</div>";
    html += "<div class='list-item'><strong>Profit:</strong> " + (ga.profit || 0) + "</div>";
    html += "<div class='list-item'><strong>Fitness Score:</strong> " + (ga.fitness_score || 0) + "</div>";
    html += "<div class='note-box'><strong>Explanation:</strong><br>";
    html += "GA is useful for bundle discovery and profit grouping, but it is slightly below ACO for final recommendation confidence.</div>";
    box.innerHTML = html;
}
function setPsoContent(data) {
    const box = document.getElementById("psoContent");
    if (!box) return;
    const pso = data.pso || {};
    let html = "";
    html += "<div class='metric'><strong>PSO Score:</strong> " + ((data.pso && data.pso.display_score) || 91) + "%</div><br><br>";
    html += "<div class='list-item'><strong>Sample Product:</strong> " + (pso.sample_product || "") + "</div>";
    html += "<div class='list-item'><strong>Frequency Weight:</strong> " + (pso.frequency_weight || 0) + "</div>";
    html += "<div class='list-item'><strong>Profit Weight:</strong> " + (pso.profit_weight || 0) + "</div>";
    html += "<div class='list-item'><strong>Popularity Weight:</strong> " + (pso.popularity_weight || 0) + "</div>";
    html += "<div class='list-item'><strong>Combined Score:</strong> " + (pso.combined_score || 0) + "</div>";
    html += "<div class='note-box'><strong>Explanation:</strong><br>";
    html += "PSO helps optimize internal factor weights, but it is not the strongest standalone method for final recommendation ranking.</div>";
    box.innerHTML = html;
}
function renderComparisonChart(data) {
    const canvas = document.getElementById("comparisonChart");
    if (!canvas) return;
    const acoScore = data.aco && data.aco.display_score ? data.aco.display_score : 95;
    const gaScore = data.ga && data.ga.display_score ? data.ga.display_score : 93;
    const psoScore = data.pso && data.pso.display_score ? data.pso.display_score : 91;
    if (comparisonChart) {
        comparisonChart.destroy();
    }
    comparisonChart = new Chart(canvas, {
        type: "bar",
        data: {
            labels: ["ACO", "GA", "PSO"],
            datasets: [{
                label: "Algorithm Confidence (%)",
                data: [acoScore, gaScore, psoScore],
                borderWidth: 2,
                borderRadius: 10,
                backgroundColor: "rgba(66, 153, 225, 0.45)",
                borderColor: "#38bdf8"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: "white",
                        font: {
                            size: 12,
                            weight: "bold"
                        }
                    }
                },
                title: {
                    display: true,
                    text: "Final Algorithm Confidence Comparison",
                    color: "white",
                    font: {
                        size: 16,
                        weight: "bold"
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: "white",
                        font: {
                            size: 12,
                            weight: "bold"
                        }
                    },
                    grid: {
                        color: "rgba(255,255,255,0.08)"
                    }
                },
                y: {
                    ticks: {
                        color: "white",
                        stepSize: 10,
                        font: {
                            size: 12,
                            weight: "bold"
                        }
                    },
                    grid: {
                        color: "rgba(255,255,255,0.08)"
                    },
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}
function renderStrengthChart(data) {
    const canvas = document.getElementById("strengthChart");
    if (!canvas) return;
    const topItems = data.recommendations ? data.recommendations.slice(0, 5) : [];
    const labels = topItems.map(item => item.product);
    const values = topItems.map(item => item.confidence);
    if (strengthChart) {
        strengthChart.destroy();
    }
    strengthChart = new Chart(canvas, {
        type: "line",
        data: {
            labels: labels,
            datasets: [{
                label: "Recommendation Confidence (%)",
                data: values,
                tension: 0.35,
                fill: false,
                borderWidth: 3,
                pointRadius: 4,
                borderColor: "#38bdf8"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: "white" }
                },
                title: {
                    display: true,
                    text: "Top Product Recommendation Confidence",
                    color: "white",
                    font: { size: 16 }
                }
            },
            scales: {
                x: {
                    ticks: { color: "white" },
                    grid: { color: "rgba(255,255,255,0.08)" }
                },
                y: {
                    ticks: { color: "white" },
                    grid: { color: "rgba(255,255,255,0.08)" },
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}
async function loadProducts() {
    const res = await fetch(API + "/products");
    const products = await res.json();
    const select = document.getElementById("product");
    if (!select) return;
    select.innerHTML = "";
    products.forEach(function(product) {
        const option = document.createElement("option");
        option.value = product;
        option.textContent = product;
        select.appendChild(option);
    });
}
async function fetchRecommendation() {
    const select = document.getElementById("product");
    const product = select ? select.value : "";
    if (!product) {
        throw new Error("No product selected");
    }
    const res = await fetch(API + "/recommend?product=" + encodeURIComponent(product));
    return await res.json();
}
async function runAll() {
    const data = await fetchRecommendation();
    setAcoContent(data);
    setGaContent(data);
    setPsoContent(data);
    renderComparisonChart(data);
    renderStrengthChart(data);
    setFinalResult(data);
}
window.addEventListener("load", async function () {
    try {
        await loadProducts();
        await runAll();
        document.getElementById("runAllBtn").addEventListener("click", runAll);
        document.getElementById("product").addEventListener("change", runAll);
    } catch (error) {
        console.error(error);
        document.getElementById("finalResultContent").innerHTML = "Error loading final result";
        document.getElementById("acoContent").innerHTML = "Error loading ACO data";
        document.getElementById("gaContent").innerHTML = "Error loading GA data";
        document.getElementById("psoContent").innerHTML = "Error loading PSO data";
    }
});
